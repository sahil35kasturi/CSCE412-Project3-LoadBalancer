var struct_request =
[
    [ "Request", "struct_request.html#a468c275a4bf1197d00cfa556340f877f", null ],
    [ "ipIn", "struct_request.html#aa83b5e8331e7f13fb5742984f955d0c1", null ],
    [ "ipOut", "struct_request.html#af585c7ba4ed14c760cf8d72b232091b4", null ],
    [ "jobType", "struct_request.html#ad49a0f18615ea50f9a11cd2494c93044", null ],
    [ "timeRequired", "struct_request.html#a250f82c8bed50b4b4f54a6eb1fef5b1c", null ]
];
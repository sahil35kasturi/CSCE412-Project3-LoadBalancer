var searchData=
[
  ['jobtype_0',['jobType',['../struct_request.html#ad49a0f18615ea50f9a11cd2494c93044',1,'Request']]]
];

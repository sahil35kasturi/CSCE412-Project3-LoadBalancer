var searchData=
[
  ['isblocked_0',['isBlocked',['../class_load_balancer.html#a5cd8146a9c9b33ee62b6497120a85561',1,'LoadBalancer']]],
  ['isbusy_1',['isBusy',['../class_web_server.html#a9a382239f638ad2b1f57621a37430874',1,'WebServer']]]
];

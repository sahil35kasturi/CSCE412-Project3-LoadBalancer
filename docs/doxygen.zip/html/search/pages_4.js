var searchData=
[
  ['features_0',['Key Features',['../index.html#functionality',1,'']]]
];

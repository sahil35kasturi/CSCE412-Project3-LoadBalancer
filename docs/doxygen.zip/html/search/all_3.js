var searchData=
[
  ['balancer_20simulation_0',['CSCE 412 Project 3 - Load Balancer Simulation',['../index.html',1,'']]],
  ['blockedips_1',['blockedIPs',['../class_load_balancer.html#ae9c8459fa8e9176d457e3a8d6db8b529',1,'LoadBalancer']]],
  ['busy_2',['busy',['../class_web_server.html#a702afd03031519bc17e80bbbc0370c5a',1,'WebServer']]]
];

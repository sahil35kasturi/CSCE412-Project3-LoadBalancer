var searchData=
[
  ['maxtasktime_0',['maxTaskTime',['../class_load_balancer.html#a58e5b781b09642b3c9240429a090bb02',1,'LoadBalancer']]],
  ['minservers_1',['minServers',['../class_load_balancer.html#a4ff267e5a18a988fe5cfcb31690544f5',1,'LoadBalancer']]],
  ['mintasktime_2',['minTaskTime',['../class_load_balancer.html#add35092be5c6034b5b9db1ae24bee22e',1,'LoadBalancer']]]
];

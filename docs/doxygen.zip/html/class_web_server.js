var class_web_server =
[
    [ "WebServer", "class_web_server.html#a5044757cd8574d3f62a7eec5d51fb00f", null ],
    [ "assignRequest", "class_web_server.html#a3e85badc291a47efdff1eb1339f5548e", null ],
    [ "getId", "class_web_server.html#aeb7683db74eccb456592ff2f1dc211d8", null ],
    [ "getTimeRemaining", "class_web_server.html#a163ff6b69afc563a29a38975d266cc9c", null ],
    [ "isBusy", "class_web_server.html#a9a382239f638ad2b1f57621a37430874", null ],
    [ "tick", "class_web_server.html#aa70cfd8749f4aee55c60e09a5f9211f7", null ],
    [ "busy", "class_web_server.html#a702afd03031519bc17e80bbbc0370c5a", null ],
    [ "id", "class_web_server.html#a02fff1dd9414d0fd6ff7960087b41038", null ],
    [ "timeRemaining", "class_web_server.html#a908c1614efb60d8ea72e4b137894becb", null ]
];